
## README
- end-to-end Solution Architect forum is contributing this as knowledge sharing. You are free to use and modify this. 
- Please check repository https://github.com/e2eSolutionArchitect/terraform
- We encourage you to contribute your knowledge with us and create a stronger IT community.
- Please feel free to contract us at https://e2esolutionarchitect.com/

# rename app_tfvars file name to as app.tfvars and then execute  below command
```
 terraform apply -var-file="app.tfvars" -var="createdBy=e2esa"
```