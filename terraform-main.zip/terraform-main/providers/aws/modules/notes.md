Modules notes

```
module "module-name"{
source ="git::https://github.com/e2eSolutionArchitect/terraform.git//provider/aws/modules/e2esa-aws-vpc?ref=main"
source ="git::https://github.com/e2eSolutionArchitect/terraform.git//<path/to/module directory>/<module directoryname>?ref=<branch or tag>"
}

```
