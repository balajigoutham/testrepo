## "Checkov" is an opensource IaC security scanning tool which is used with Terraform [Click here](https://www.checkov.io/1.Welcome/Quick%20Start.html) to know more. 

## Installation steps [Click here](https://www.checkov.io/2.Basics/Installing%20Checkov.html) 
