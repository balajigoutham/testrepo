### List of AWS Examples

- S3 Backend configuration for Terraform State Management
- VPC


### List of AWS Modules

- e2esa-terraform-aws-vpc

### For Terraform professional consultancy and Technology advisory please feel free to drop a note to som@e2eSolutionArchitect.com
